const colorMapping = {
    "A1": "#fa717b", "A2": "#fa717b", "A3": "#bc5d5e", "A4": "#000000", "A5": "#bc5d5e", "A6": "#000000", 
    "A7": "#000000", "A8": "#fa717b", "A9": "#000000", "A10": "#bc5d5e", "A11": "#fa717b", "A12": "#fa717b",
    "A13": "#fa717b", "A14": "#fa717b", "A15": "#000000", "A16": "#fa717b", "A17": "#000000", "A18": "#bc5d5e",
    "A19": "#000000", "A20": "#000000", "A21": "#000000", "A22": "#000000",
    
    "B1": "#fa717b", "B2": "#bc5d5e", "B3": "#bc5d5e", "B4": "#fa717b", "B5": "#bc5d5e", "B6": "#fa717b",
    "B7": "#bc5d5e", "B8": "#fa717b", "B9": "#000000", "B10": "#bc5d5e", "B11": "#000000", "B12": "#000000",
    "B13": "#fa717b", "B14": "#fa717b", "B15": "#000000", "B16": "#000000", "B17": "#000000", "B18": "#fa717b",
    "B19": "#fa717b", "B20": "#000000", "B21": "#000000", "B22": "#000000",
    
    "C1": "#fd0203", "C2": "#910101", "C3": "#910101", "C4": "#bc5d5e", "C5": "#910101", "C6": "#dd0430",
    "C7": "#dd0430", "C8": "#fd0203", "C9": "#fa717b", "C10": "#dd0430", "C11": "#bc5d5e", "C12": "#dd0430",
    "C13": "#fa717b", "C14": "#fa717b", "C15": "#dd0430", "C16": "#dd0430", "C17": "#bc5d5e", "C18": "#000000",
    "C19": "#fa717b", "C20": "#fd0203", "C21": "#fa717b", "C22": "#000000",
    
    "D1": "#910101", "D2": "#910101", "D3": "#fd0203", "D4": "#fd0203", "D5": "#910101", "D6": "#910101",
    "D7": "#dd0430", "D8": "#910101", "D9": "#bc5d5e", "D10": "#fd0203", "D11": "#fd0203", "D12": "#fd0203",
    "D13": "#bc5d5e", "D14": "#fa717b", "D15": "#fd0203", "D16": "#fd0203", "D17": "#fd0203", "D18": "#000000",
    "D19": "#bc5d5e", "D20": "#910101", "D21": "#bc5d5e", "D22": "#fa717b",
    
    "E1": "#fd0203", "E2": "#fd0203", "E3": "#bc5d5e", "E4": "#dd0430", "E5": "#fd0203", "E6": "#fd0203",
    "E7": "#fa717b", "E8": "#910101", "E9": "#dd0430", "E10": "#bc5d5e", "E11": "#dd0430", "E12": "#bc5d5e",
    "E13": "#fa717b", "E14": "#fa717b", "E15": "#dd0430", "E16": "#fd0203", "E17": "#dd0430", "E18": "#000000",
    "E19": "#bc5d5e", "E20": "#fd0203", "E21": "#bc5d5e", "E22": "#fa717b",
    
    "F1": "#dd0430", "F2": "#dd0430", "F3": "#000000", "F4": "#fa717b", "F5": "#bc5d5e", "F6": "#dd0430",
    "F7": "#000000", "F8": "#fd0203", "F9": "#bc5d5e", "F10": "#fa717b", "F11": "#bc5d5e", "F12": "#fa717b",
    "F13": "#000000", "F14": "#fa717b", "F15": "#fa717b", "F16": "#fa717b", "F17": "#fa717b", "F18": "#000000",
    "F19": "#000000", "F20": "#bc5d5e", "F21": "#fa717b", "F22": "#bc5d5e",
    
    "G1": "#bc5d5e", "G2": "#fa717b", "G3": "#000000", "G4": "#fa717b", "G5": "#000000", "G6": "#bc5d5e",
    "G7": "#000000", "G8": "#bc5d5e", "G9": "#fa717b", "G10": "#000000", "G11": "#000000", "G12": "#000000",
    "G13": "#000000", "G14": "#fa717b", "G15": "#000000", "G16": "#fa717b", "G17": "#000000", "G18": "#000000",
    "G19": "#000000", "G20": "#fa717b", "G21": "#000000", "G22": "#000000"
};

function generateTable() {
    const table = document.getElementById('data-table');
    const rows = 7; // A through G (0.5 to 3.5 hours)
    const cols = 22; // 1 through 22 (genres)
    const rowLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
    
    // Clear existing content
    table.innerHTML = '';
    
    for (let row = 0; row < rows; row++) {
        const tr = document.createElement('tr');
        
        for (let col = 0; col < cols; col++) {
            const td = document.createElement('td');
            const cellKey = rowLabels[row] + (col + 1);
            
            // Apply color from mapping
            if (colorMapping[cellKey]) {
                td.style.backgroundColor = colorMapping[cellKey];
            } else {
                // Default color if no mapping found
                td.style.backgroundColor = '#333333';
            }
            
            tr.appendChild(td);
        }
        
        table.appendChild(tr);
    }
}

// Generate table when page loads
document.addEventListener('DOMContentLoaded', function() {
    generateTable();
    
    // Handle window resize for responsive design
    window.addEventListener('resize', function() {
        // Recalculate sizes if needed
        setTimeout(() => {
            generateTable();
        }, 100);
    });
});

// Function to update color mapping (call this with your Excel data)
function updateColorMapping(newColorData) {
    Object.assign(colorMapping, newColorData);
    generateTable();
}

// Example of how to load color data from Excel:
// To use this with your actual Excel file, you would need to:
// 1. Convert Excel to JSON format, or
// 2. Use a library like SheetJS to read Excel files, or  
// 3. Export Excel as CSV and parse it
// 
// Example format for your color data:
// const excelColorData = {
//     "A1": "#your_color_code",
//     "A2": "#your_color_code", 
//     // ... etc for all 154 cells (7 rows × 22 columns)
// };
// updateColorMapping(excelColorData);